#!/bin/bash

postProcess -func sampleDict -latestTime
gnuplot gnuplot/gnuplot_script 

#------------------------------------------------------------------------------ 
